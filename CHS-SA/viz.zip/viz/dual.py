from dash import Dash, dcc, html, Input, Output
import plotly.express as px
app = Dash(__name__)

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Example Gantt data
df_gantt = pd.DataFrame({
    "bus_id": ["Bus1", "Bus1", "Bus2", "Bus2"],
    "trip_id": ["T1", "T2", "T3", "T4"],
    "dep_time_min": [420, 600, 480, 720],
    "arr_time_min": [480, 660, 540, 780]
})

base_date = pd.Timestamp("2025-01-01")
df_gantt["dep_time"] = base_date + pd.to_timedelta(df_gantt["dep_time_min"], unit="m")
df_gantt["arr_time"] = base_date + pd.to_timedelta(df_gantt["arr_time_min"], unit="m")
# Create fake SoC data for each bus
time_range = pd.date_range(base_date, base_date + pd.Timedelta("24h"), freq="10min")

soc_data = []
for bus in ["Bus1", "Bus2"]:
    soc = 100 - np.linspace(0, 70, len(time_range)) + np.random.normal(0, 2, len(time_range))
    soc_data.append(pd.DataFrame({
        "bus_id": bus,
        "time": time_range,
        "soc": np.clip(soc, 0, 100)
    }))
df_soc = pd.concat(soc_data)

print(f"SOC={df_soc}")

# Create the Gantt chart
fig_gantt = px.timeline(
    df_gantt, 
    x_start="dep_time", x_end="arr_time", 
    y="bus_id", color="trip_id",
    title="Electric Bus Timetable"
)
fig_gantt.update_yaxes(autorange="reversed")

# Layout
app.layout = html.Div([
    html.H3("Electric Bus Rostering Dashboard"),
    dcc.Graph(id="gantt", figure=fig_gantt),
    html.Hr(),
    html.H4("Battery State of Charge (SoC)"),
    dcc.Graph(id="soc_line")
])

# Callback: when user clicks a trip block on the Gantt
@app.callback(
    Output("soc_line", "figure"),
    Input("gantt", "clickData")
)
def show_soc_line(clickData):
    if not clickData:
        return go.Figure()

    # Get clicked bus_id
    bus_clicked = clickData["points"][0]["y"]

    # Filter the SoC data
    df_selected = df_soc[df_soc["bus_id"] == bus_clicked]

    # Create line chart
    fig = px.line(df_selected, x="time", y="soc", title=f"SoC over Time - {bus_clicked}")
    fig.update_yaxes(title="State of Charge (%)", range=[0, 100])
    fig.update_xaxes(title="Time of Day", tickformat="%H:%M")

    return fig


if __name__ == "__main__":
    app.run(debug=True)
