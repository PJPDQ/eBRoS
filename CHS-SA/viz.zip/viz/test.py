# app.py
from flask import Flask, render_template, request, jsonify
import pandas as pd
import plotly.express as px
import plotly.io as pio

app = Flask(__name__)

# sample dataframe
df = pd.DataFrame({
    'bus_id': ['Bus1', 'Bus1', 'Bus2', 'Bus2'],
    'trip_id': ['T1', 'T2', 'T3', 'T4'],
    'dep_time': [0, 300, 100, 500],
    'arr_time': [200, 450, 400, 700],
    'SoC_start': [100, 60, 100, 70],
    'SoC_end': [60, 80, 70, 90]
})

@app.route('/')
def index():
    # sample dataframe
    data = {
        "bus_id": ["Bus1", "Bus1", "Bus2", "Bus2"],
        "trip_id": ["T1", "T2", "T3", "T4"],
        "dep_time_min": [420, 600, 480, 720],  # departure time in minutes since midnight
        "arr_time_min": [480, 660, 540, 780]   # arrival time in minutes since midnight
    }

    df = pd.DataFrame(data)
    # Convert minutes to datetime (e.g., Jan 1, 2025)
    base_date = pd.Timestamp("2025-01-01")
    df["dep_time_dt"] = base_date + pd.to_timedelta(df["dep_time_min"], unit="m")
    df["arr_time_dt"] = base_date + pd.to_timedelta(df["arr_time_min"], unit="m")
    df = df[['bus_id', 'trip_id', 'dep_time_dt', 'arr_time_dt']]
    print("-"*100)
    print(df.dtypes)
    fig = px.timeline(df, x_start="dep_time_dt", x_end="arr_time_dt", y="bus_id",
                      color="trip_id", title="Electric Bus Rostering Overview")
    
    
    print(df.head())
    print("-"*100)
    fig.update_yaxes(autorange="reversed")  # Gantt charts usually reversed
    fig.update_xaxes(title="Time of Day", tickformat="%H:%M")
    fig.write_html("my_interactive_plot.html")
    gantt_html = pio.to_html(fig, full_html=False, include_plotlyjs=True)
    return render_template("index.html", gantt=gantt_html)

@app.route('/bus_soc/<bus_id>')
def bus_soc(bus_id):
    subset = df[df['bus_id'] == bus_id]
    soc_df = pd.DataFrame({
        'time': subset[['dep_time', 'arr_time']].values.flatten(),
        'SoC': subset[['SoC_start', 'SoC_end']].values.flatten()
    }).sort_values(by='time')
    soc_fig = px.line(soc_df, x='time', y='SoC', title=f"SoC Over Time for {bus_id}")
    return jsonify({'plot': pio.to_html(soc_fig, full_html=False)})

if __name__ == '__main__':
    app.run(debug=True)
